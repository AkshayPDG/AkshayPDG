import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  public createNewPost(){
      this.router.navigate(["/social-media-selector"])
  }

  public logout(){
    this.router.navigate(['/logout']);
  }

}
