import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataHandlerService } from 'src/app/data-handler.service';
import { NavBarService } from 'src/app/nav-bar.service';
import { AuthenticationService } from '../auth-service/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public username =""
  public password= ""

  constructor(private router: Router, private _authService:AuthenticationService, private _dataHandler: DataHandlerService, public _nav: NavBarService) { }

  ngOnInit(): void {
    this._nav.hide();
  }

  public login(){
    if (this._authService.authenticate(this.username, this.password)){
      this.setUsername()
      sessionStorage.setItem("social-poc-user", this.username)
      // localStorage.setItem("social-poc-user", this.username)
      this._nav.show();
      this.router.navigate(["/dashboard"])
    }
  }

  private setUsername(){
    this._dataHandler.changeMessage(this.username)
  }
}
