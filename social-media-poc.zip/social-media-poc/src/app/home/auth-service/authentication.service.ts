import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  //dummy user-creds for poc
  private usernames= ["admin", "poc-user", "zeenews"]
  private passwords= ["admin", "poc-user", "zeenews"]

  constructor() { }
  public isUserLoggedIn(){
    var user = sessionStorage.getItem('social-poc-user');
    // var user = localStorage.getItem('social-poc-user')
    // user !== null? sessionStorage.setItem('social-poc-user', user):'';
    return !(user === null)
  }
  public authenticate(username: string, password: string): boolean {
    //array index from dummy user-creds
    var usernumber= this.usernames.indexOf(username);
    if((usernumber !== -1) && (this.passwords.indexOf(password) === usernumber)){
      return true;
    }
    return false
  }

  public logout(){
    // localStorage.clear();
    sessionStorage.clear();
  }
}
