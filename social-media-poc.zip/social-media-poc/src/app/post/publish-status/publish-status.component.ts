import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-publish-status',
  templateUrl: './publish-status.component.html',
  styleUrls: ['./publish-status.component.css']
})
export class PublishStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
