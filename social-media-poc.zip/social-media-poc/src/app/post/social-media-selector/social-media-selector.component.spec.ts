import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SocialMediaSelectorComponent } from './social-media-selector.component';

describe('SocialMediaSelectorComponent', () => {
  let component: SocialMediaSelectorComponent;
  let fixture: ComponentFixture<SocialMediaSelectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SocialMediaSelectorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SocialMediaSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
