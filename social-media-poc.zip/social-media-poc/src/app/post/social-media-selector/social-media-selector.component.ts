import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SocialMediaAuthService } from '../services/social-media-auth.service';
import { DataHandlerService } from 'src/app/data-handler.service';
import { AuthData as AuthData } from '../models/AuthData';

@Component({
  selector: 'app-social-media-selector',
  templateUrl: './social-media-selector.component.html',
  styleUrls: ['./social-media-selector.component.css']
})
export class SocialMediaSelectorComponent implements OnInit {
  selectMessage = "";
  username: string | null = "";
  authDataList:AuthData[] = []

  ytDisabled = true;
  fbDisabled = true;
  igDisabled = true;
  trDisabled = true;

  //allowed platforms to be filled
  readonly platforms: string[] = ["Youtube", "Facebook", "Instagram", "Twitter"];
  //user selected platforms
  selectedplatforms: string[]= [];

  constructor(private router: Router, private _socialAuthService: SocialMediaAuthService, private _dataHandler: DataHandlerService) { }
  
  ngOnInit(): void {
    // this._dataHandler.currentMessage.subscribe(nameData => (this.username= nameData));
    this.username = sessionStorage.getItem("social-poc-user");
  }

  addplatform(platform:string): void {
    console.log("username: ",this.username)
    var existItem = this.selectedplatforms.find(x=>x==platform);
    if(!existItem){
      let currentPlatformAuthKey = this.username + "-" + platform// + "-" + dateTimeStamp.toUTCString;
      ///
      let currentTokenData = new AuthData();
      currentTokenData.platform = platform;
      currentTokenData.platformAuthKey = currentPlatformAuthKey;
      this._socialAuthService.socialAccountAuthenticate(platform.toLowerCase(), currentPlatformAuthKey).subscribe(
        (data:any) =>{
          console.log("data: ",data)
          console.log("status: ",data.status)

          let index = this.authDataList.push(currentTokenData)
          this.selectedplatforms.push(platform);
          this.setAuthData();
          this.enableLogo(platform);
        });
    }
  }

  removePlatform(platform: string): void {
    const index = this.selectedplatforms.indexOf(platform);

    if (index >= 0) {
      this.selectedplatforms.splice(index, 1);
      let tokenIndex= this.authDataList.findIndex(x=> x.platform == platform);
      this.authDataList.splice(tokenIndex, 1);
      this.setAuthData();
      this.disableLogo(platform)
    }
  }

  public changePlatformStatus(platformIndex: number){
    let platform = this.platforms[platformIndex];
    var existItem = this.selectedplatforms.find(x=>x==platform);
    if(!existItem){
      this.addplatform(platform)
    } else {
      this.removePlatform(platform)
    }
  }

  public nextPublishMedia(){
    if( this.selectedplatforms.length > 0 && this.authDataList.length > 0){
      this.router.navigate(["/publish-media"])
    } else {
      this.selectMessage = "Please select atleast one social media platform for publishing by clicking on logo"
    }
  }

  public cancelPublishMedia(){
    this.router.navigate(["/dashboard"])
  }

  private setAuthData(){
    this._dataHandler.changeMessage(this.authDataList)
  }

  private enableLogo(platform: string){
    switch(platform) { 
      case "Youtube": { 
         this.ytDisabled= false; 
         break; 
      } 
      case "Facebook": { 
         this.fbDisabled= false;
         break; 
      } 
      case "Instagram": {
         this.igDisabled = false;
         break;    
      } 
      case "Twitter": { 
         this.trDisabled = false; 
         break; 
      }  
      default: { 
         console.log("Invalid choice"); 
         break;              
      } 
   }
  }

  private disableLogo(platform: string){
    switch(platform) { 
      case "Youtube": { 
         this.ytDisabled= true; 
         break; 
      } 
      case "Facebook": { 
         this.fbDisabled= true;
         break; 
      } 
      case "Instagram": {
         this.igDisabled = true;
         break;    
      } 
      case "Twitter": { 
         this.trDisabled = true; 
         break; 
      }  
      default: { 
         console.log("Invalid choice"); 
         break;              
      } 
   }
  }
}
