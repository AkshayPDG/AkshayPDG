import { Component, OnInit } from '@angular/core';
import { Output, EventEmitter } from '@angular/core';
import { Caption } from '../models/Caption';

@Component({
  selector: 'app-caption',
  templateUrl: './caption.component.html',
  styleUrls: ['./caption.component.css']
})
export class CaptionComponent implements OnInit {
  captionData = new Caption();

  @Output() newCaptionEvent = new EventEmitter<Caption>();

  addNewCaption() {
    // console.log(this.captionData)
    this.newCaptionEvent.emit(this.captionData);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
