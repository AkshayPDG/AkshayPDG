import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SocialMediaAuthService {
  readonly rootUrl = "http://localhost:8080/auth-login";
  constructor(private _http: HttpClient) { }
  public socialAccountAuthenticate(platform:string , platformAuthKey: string): Observable<any> {
    // var body = {
    //   "username": platformUsername
    // };
    const formData: FormData = new FormData();
    formData.append("auth-key", platformAuthKey);
    console.log(this.rootUrl+"/"+platform);
    return this._http.post<any>(this.rootUrl+"/"+platform, formData, {observe: 'response'});
  }

}
