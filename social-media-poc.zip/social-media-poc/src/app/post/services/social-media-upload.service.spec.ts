import { TestBed } from '@angular/core/testing';

import { SocialMediaUploadService } from './social-media-upload.service';

describe('SocialMediaUploadService', () => {
  let service: SocialMediaUploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SocialMediaUploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
