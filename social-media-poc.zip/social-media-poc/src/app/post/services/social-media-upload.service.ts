import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SocialMediaUploadService {
  readonly rootUrl = "http://localhost:8080/publish-media";
  constructor(private _http: HttpClient) { }

  public uploadMedia(body: FormData): Observable<any>{
    return this._http.post(this.rootUrl,body);
  }
}
