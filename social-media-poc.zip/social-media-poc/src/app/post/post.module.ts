import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CaptionComponent } from './caption/caption.component';
import { SocialMediaSelectorComponent } from './social-media-selector/social-media-selector.component';
import { SchedulerComponent } from './scheduler/scheduler.component';
import { PublishBoardComponent } from './publish-board/publish-board.component';
import {MatChipsModule} from '@angular/material/chips';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatMenuModule} from '@angular/material/menu';
import {MatButtonModule} from '@angular/material/button';
import { MediaTagsComponent } from './media-tags/media-tags.component';
import { PublishStatusComponent } from './publish-status/publish-status.component';
import { FileSelectorComponent } from './file-selector/file-selector.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    CaptionComponent,
    SocialMediaSelectorComponent,
    SchedulerComponent,
    PublishBoardComponent,
    MediaTagsComponent,
    PublishStatusComponent,
    FileSelectorComponent
  ],
  imports: [
    CommonModule,
    MatChipsModule,
    MatFormFieldModule,
    MatMenuModule,
    MatButtonModule,
    FormsModule,
  ]
})
export class PostModule { }
