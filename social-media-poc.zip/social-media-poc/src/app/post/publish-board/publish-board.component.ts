import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataHandlerService } from 'src/app/data-handler.service';
import { Caption } from '../models/Caption';
import { MediaData } from '../models/MediaData';
import { AuthData } from '../models/AuthData';
import { SocialMediaUploadService } from '../services/social-media-upload.service';

@Component({
  selector: 'app-publish-board',
  templateUrl: './publish-board.component.html',
  styleUrls: ['./publish-board.component.css']
})
export class PublishBoardComponent implements OnInit {
  displayMessage=""
  formData= new FormData; 
  authDataList:AuthData[] = []
  mediaData = new MediaData()
  constructor(private _router: Router, private _mediaPublish: SocialMediaUploadService, private _dataHandler: DataHandlerService) { }

  ngOnInit(): void {
    this._dataHandler.currentMessage.subscribe(authData => (this.authDataList= authData));
    if(this.authDataList.length == 0){
      this._router.navigate(['/social-media-selector']);
    }
  }

  addCaption(newCaption: Caption) {
    this.mediaData.title = newCaption.title;
    this.mediaData.caption = newCaption.caption;
    this.mediaData.link = newCaption.link;
  }
  addTags(newTags: string[]){
    this.mediaData.tags = newTags;
  }
  addfile(newFile: File){
    this.formData.append("file", newFile);
  }

  public publishMedia(){
    this.displayMessage="";
    this.formData.append("title" , this.mediaData.title);
    this.formData.append("caption", this.mediaData.caption);
    this.formData.append("link", this.mediaData.link);
    this.formData.append("tags", this.mediaData.tags.toString());
    this.formData.append("schedule", "")
    this.formData.append("youtube-authkey", this.getAuthKey("Youtube"));
    this.formData.append("facebook-authkey", this.getAuthKey("Facebook"));
    console.log(this.formData.get("title"));
    console.log(this.formData.get("caption"));
    console.log(this.formData.get("link"));
    console.log(this.formData.get("tags"));
    console.log(this.formData.get("file"));
    console.log(this.formData.get("schedule"));
    console.log(this.formData.get("youtube-authkey"));
    console.log(this.formData.get("facebook-authkey"));


    this._mediaPublish.uploadMedia(this.formData).subscribe(
      data => {
        console.log(data)
        // console.log(data)
        if(data !== null){
          this._router.navigate(["/dashboard"])
        }else{
          this.displayMessage = "Failed to publish"
        }
      }
    )
  }

  private getAuthKey(platform: string): string{
    let authKeyIndex = this.authDataList.findIndex(ad => ad.platform === platform);
    return authKeyIndex != -1 ? this.authDataList[authKeyIndex].platformAuthKey : "";
  }
  public cancelPublish(){
    this._router.navigate(["/dashboard"])
  }
}
