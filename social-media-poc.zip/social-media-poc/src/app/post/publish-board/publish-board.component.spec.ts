import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PublishBoardComponent } from './publish-board.component';

describe('PublishBoardComponent', () => {
  let component: PublishBoardComponent;
  let fixture: ComponentFixture<PublishBoardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PublishBoardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PublishBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
