import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-file-selector',
  templateUrl: './file-selector.component.html',
  styleUrls: ['./file-selector.component.css']
})
export class FileSelectorComponent implements OnInit {

  selectFile(event: any) {
    let mediaFile: File = event.target.files[0];
    console.log(mediaFile)
    this.addNewItem(mediaFile);
  }

  @Output() newItemEvent = new EventEmitter<File>();

  addNewItem(mediaFile: File) {
    this.newItemEvent.emit(mediaFile);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
