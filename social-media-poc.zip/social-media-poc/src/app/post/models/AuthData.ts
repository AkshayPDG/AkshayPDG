export class AuthData{
    platform= "";
    platformAuthKey="";
}