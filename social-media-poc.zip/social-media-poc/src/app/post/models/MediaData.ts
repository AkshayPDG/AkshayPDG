export class MediaData{
    title = "";
    caption = "";
    link = "";
    tags: string[] = [];
}