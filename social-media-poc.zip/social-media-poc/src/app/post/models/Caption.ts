export class Caption{
    title= ""
    caption = ""
    link = ""
  }